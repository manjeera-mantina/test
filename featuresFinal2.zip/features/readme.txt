This is a readme for this Portfolio project.

I would like to highlight the features that have been implemented in making this project.

1. Implemented the "fetch" feature of Javascript to import the information from my github account api.github.com/users/manjeera-mantina
	On clicking on My Portfolio, picture and github account are displayed
2. Implemented the "transition" and "tranform" features to increase the size of the button-sized images.
3. Used the "title" feature to display the description of the figure when mouse hovers on.
4. Used the "id" in the href of the link to link to different places within the webpage.
5. Implemented the "alert" function to display message on clicking buttons.
6. Implemented "fadein" and "fadeout" in CSS on hovering on images with written description.
7. Used the bootstrap of "features" folder from the provided samples, for the layout of the webpage.
8. Using github to upload the project and provide a shareable link.

Would like to thank the teacher Mr. Spencer and my cohortmates for inspiring me to do, and my family in adjusting for me to do the project.