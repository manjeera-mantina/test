function reflectDiv(elementBut,elementDiv){
    var presLikes = elementDiv.innerText++;
    console.log(presLikes);
}