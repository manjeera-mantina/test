
function countLikes(numlikes){
    numlikes.innerText += 1;
}
console.log("hi");