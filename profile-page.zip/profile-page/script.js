console.log("page loaded...");
function acceptFriend(elementLi, elementCnt, elementFr){
elementCnt.innerText--;
 elementLi.remove();
elementFr.innerText++;
}
function happyFriend(elementLi, elementCnt){
    elementCnt.innerText--;
    elementLi.remove();
}
function changUser(elementUser){
    console.log("in");
    //console.log(elementUser.innerText);
    elementUser.textContent = "Ms. Jane Doe";
}