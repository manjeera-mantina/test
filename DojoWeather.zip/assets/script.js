console.log("page loaded");
var tdl = document.querySelector("#tdl");
var tdh = document.querySelector("#tdh");
var tmh = document.querySelector("#tmh");
var tml = document.querySelector("#tml");
var fdh = document.querySelector("#fdh");
var fdl = document.querySelector("#fdl");
var sdh = document.querySelector("#sdh");
var sdl = document.querySelector("#sdl");

function dispAlrt(element){
    console.log(element.innerText);
    alert("You are viewing the weather of " + element.innerText);
}
/*function sortinBy(selectEle, DispEle){
    console.log("in the display change function");
    DispEle.innerText = selectEle.value;
}
function provInfo(){
    alert("Please call 1-888-8888 for more information")
}*/
function getRid(element){
    element.remove();
}
function F2C(){
    console.log("yes to C");
    var tempF = parseInt(tdh.innerText);
    var tempC = Math.round((tempF - 32)* 5 / 9);
    tdh.innerText = tempC;
    var tempF = parseInt(tdl.innerText);
    var tempC = Math.round((tempF - 32)* 5 / 9);
    tdl.innerText = tempC;
    var tempF = parseInt(tmh.innerText);
    var tempC = Math.round((tempF - 32)* 5 / 9);
    tmh.innerText = tempC;
    var tempF = parseInt(tml.innerText);
    var tempC = Math.round((tempF - 32)* 5 / 9);
    tml.innerText = tempC;
    var tempF = parseInt(fdh.innerText);
    var tempC = Math.round((tempF - 32)* 5 / 9);
    fdh.innerText = tempC;
    var tempF = parseInt(fdl.innerText);
    var tempC = Math.round((tempF - 32)* 5 / 9);
    fdl.innerText = tempC;
    var tempF = parseInt(sdh.innerText);
    var tempC = Math.round((tempF - 32)* 5 / 9);
    sdh.innerText = tempC;
    var tempF = parseInt(sdl.innerText);
    var tempC = Math.round((tempF - 32)* 5 / 9);
    sdl.innerText = tempC;

}

function C2F(){
    console.log("yes to F");

    var tempC = parseInt(tdh.innerText);
    //console.log(tempC);

    var tempF = Math.round((tempC * 9 / 5) + 32);
    tdh.innerText = tempF;
    var tempC = parseInt(tdl.innerText);
    var tempF = Math.round((tempC * 9 / 5) + 32);
    tdl.innerText = tempF;
    var tempC = parseInt(tmh.innerText);
    var tempF = Math.round((tempC * 9 / 5) + 32);
    tmh.innerText = tempF;
    var tempC = parseInt(tml.innerText);
    var tempF = Math.round((tempC * 9 / 5) + 32);
    tml.innerText = tempF;
    var tempC = parseInt(fdh.innerText);
    var tempF = Math.round((tempC * 9 / 5) + 32);
    fdh.innerText = tempF;
    var tempC = parseInt(fdl.innerText);
    var tempF = Math.round((tempC * 9 / 5) + 32);
    fdl.innerText = tempF;
    var tempC = parseInt(sdh.innerText);
    var tempF = Math.round((tempC * 9 / 5) + 32);
    sdh.innerText = tempF;
    var tempC = parseInt(sdl.innerText);
    var tempF = Math.round((tempC * 9 / 5) + 32);
    sdl.innerText = tempF;

}
function conV(element){
    if(element.value == "F")
    C2F();
    else if(element.value == "C")
    F2C();
}