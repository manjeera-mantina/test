function move(element){
    element.remove();
}
function inform(element){
    alert("You are searching for '" + element.value+ "'");
}
function incres(element){
    element.innerText++;
}